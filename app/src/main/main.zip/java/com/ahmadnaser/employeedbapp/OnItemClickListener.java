package com.ahmadnaser.employeedbapp;

public interface OnItemClickListener extends
		android.widget.AdapterView.OnItemClickListener {

}
